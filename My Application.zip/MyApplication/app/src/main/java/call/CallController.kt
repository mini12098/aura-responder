package com.aura.copilot.call

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.aura.copilot.speech.SpeechManager

class CallController(
    private val context: Context,
    private val speech: SpeechManager
) {
    fun handleCallCommand(command: String) {
        val name = command.removePrefix("call ").trim()
        val number = lookupContact(name) ?: extractNumber(command)
        if (number == null) {
            speech.speak("I could not find a contact or number for $name.")
            return
        }
        speech.speak("Calling $name on speaker.")
        val intent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$number")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            // Speaker can be forced via AudioManager after call connects
        }
        context.startActivity(intent)
    }

    private fun lookupContact(name: String): String? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )
        cursor?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun extractNumber(cmd: String): String? {
        val match = Regex("""(\+?\d[\d\s-]{7,})""").find(cmd)
        return match?.value?.replace(Regex("[\\s-]"), "")
    }
}

