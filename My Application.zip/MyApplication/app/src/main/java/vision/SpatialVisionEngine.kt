package com.aura.copilot.vision

import android.content.Context
import com.aura.copilot.BuildConfig
import com.aura.copilot.speech.SpeechManager
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SpatialVisionEngine(
    private val context: Context,
    private val speech: SpeechManager
) {
    private val model = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = BuildConfig.GEMINI_API_KEY
    )
    private val camera = CameraFrameCapture(context)

    fun describeEnvironment() {
        CoroutineScope(Dispatchers.Main).launch {
            val bitmap = camera.captureFrame() ?: run {
                speech.speak("Could not capture camera frame.")
                return@launch
            }
            try {
                val prompt = """
                    You are a spatial narrator for a blind user.
                    Reply ONLY in this exact structure, concise and safety-first:
                    Immediate Hazards: ...
                    Room Type & Atmosphere: ...
                    Spatial Layout & Clock-Face Positioning: ...
                    Navigable Path: ...
                    Use 12-o'clock = straight ahead.
                """.trimIndent()

                val response = model.generateContent(content {
                    image(bitmap)
                    text(prompt)
                })
                speech.speak(response.text ?: "No description returned.")
            } catch (e: Exception) {
                speech.speak("Vision analysis failed. ${e.message}")
            }
        }
    }
}

