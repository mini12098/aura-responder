package com.aura.copilot.digilocker

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class Identity(
    val fullName: String = "",
    val dob: String = "",
    val aadhaar: String = "",
    val phone: String = "",
    val address: String = ""
)

class SecureVault(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(
        context, "aura_vault", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun load() = Identity(
        fullName = prefs.getString("fullName", "Aarav Sharma") ?: "",
        dob = prefs.getString("dob", "1992-08-14") ?: "",
        aadhaar = prefs.getString("aadhaar", "1234-5678-9012") ?: "",
        phone = prefs.getString("phone", "+919876543210") ?: "",
        address = prefs.getString("address", "42 MG Road, Bengaluru") ?: ""
    )
}