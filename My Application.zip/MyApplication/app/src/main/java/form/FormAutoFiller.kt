package com.aura.copilot.form

import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.aura.copilot.digilocker.SecureVault
import com.aura.copilot.service.AuraAccessibilityService
import com.aura.copilot.speech.SpeechManager

class FormAutoFiller(private val service: AuraAccessibilityService) {

    

    private val fieldHints = mapOf(
        "name" to listOf("name", "full name", "passenger"),
        "dob" to listOf("dob", "date of birth", "birth"),
        "aadhaar" to listOf("aadhaar", "aadhar", "id number", "identity"),
        "phone" to listOf("phone", "mobile", "contact"),
        "address" to listOf("address")
    )

    fun autoFill(root: AccessibilityNodeInfo) {
        val data = vault.load()
        var filled = 0

        traverse(root) { node ->
            val hint = (node.text?.toString() ?: "") +
                    (node.contentDescription?.toString() ?: "") +
                    (node.viewIdResourceName ?: "")

            when {
                matches(hint, fieldHints["name"]!!) && data.fullName.isNotBlank() -> {
                    setText(node, data.fullName); filled++
                }
                matches(hint, fieldHints["dob"]!!) && data.dob.isNotBlank() -> {
                    setText(node, data.dob); filled++
                }
                matches(hint, fieldHints["aadhaar"]!!) && data.aadhaar.isNotBlank() -> {
                    setText(node, data.aadhaar); filled++
                }
                matches(hint, fieldHints["phone"]!!) && data.phone.isNotBlank() -> {
                    setText(node, data.phone); filled++
                }
                matches(hint, fieldHints["address"]!!) && data.address.isNotBlank() -> {
                    setText(node, data.address); filled++
                }
            }
        }

        speech.speak(
            if (filled > 0) "Filled $filled fields from DigiLocker. Review and submit when ready."
            else "No matching fields found on this screen."
        )
    }

    private fun setText(node: AccessibilityNodeInfo, value: String) {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun matches(text: String, keywords: List<String>) =
        keywords.any { text.contains(it, ignoreCase = true) }

    private fun traverse(node: AccessibilityNodeInfo?, action: (AccessibilityNodeInfo) -> Unit) {
        if (node == null) return
        action(node)
        for (i in 0 until node.childCount) {
            traverse(node.getChild(i), action)
        }
    }
}

