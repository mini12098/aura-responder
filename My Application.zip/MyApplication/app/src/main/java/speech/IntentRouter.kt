package com.aura.copilot.speech

import android.content.Context
import android.content.Intent
import com.aura.copilot.call.CallController
import com.aura.copilot.digilocker.SecureVault
import com.aura.copilot.form.FormAutoFiller
import com.aura.copilot.vision.SpatialVisionEngine
import com.aura.copilot.service.AuraAccessibilityService

class IntentRouter(
    private val context: Context,
    private val speech: SpeechManager
) {
    private val callController = CallController(context, speech)
    private val visionEngine = SpatialVisionEngine(context, speech)
    private val secureVault = SecureVault(context)


    fun route(command: String) {
        val lowerCommand = command.lowercase().trim()

        when {
            // 1. WhatsApp Integration
            lowerCommand.contains("whatsapp") -> {
                speech.speak("Opening WhatsApp.")
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                } else {
                    speech.speak("WhatsApp is not installed.")
                }
            }

            // 2. DigiLocker / SecureVault Module
            lowerCommand.contains("digilocker") || lowerCommand.contains("locker") || lowerCommand.contains("document") -> {
                speech.speak("Accessing DigiLocker vault.")
                val identity = secureVault.load() // Calls your load() function
                // You can use the identity object or just speak a confirmation
                speech.speak("Vault loaded for ${identity.fullName}")
            }

            // 3. Form Auto-Filler Module
            // 3. Form Auto-Filler Module
            lowerCommand.contains("fill") || lowerCommand.contains("book") || lowerCommand.contains("ticket") -> {
                speech.speak("Filling form.")
                val accessibilityService = AuraAccessibilityService.instance
                if (accessibilityService != null) {
                    val rootNode = accessibilityService.rootInActiveWindow
                    if (rootNode != null) {
                        val autoFiller = FormAutoFiller(accessibilityService)
                        // Call the correct method name inside your FormAutoFiller if it's autoFill()
                        autoFiller.autoFill(rootNode)
                        speech.speak("Form filled.")
                    } else {
                        speech.speak("No form window found.")
                    }
                } else {
                    speech.speak("Accessibility service is not enabled.")
                }
            }

            // 4. Vision Engine Module
            lowerCommand.contains("describe") || lowerCommand.contains("scan") ||
                    lowerCommand.contains("room") || lowerCommand.contains("environment") ||
                    lowerCommand.contains("around me") -> {
                speech.speak("Scanning environment.")
                visionEngine.describeEnvironment()
            }

            // 5. Call Controller Module
            lowerCommand.startsWith("call ") || lowerCommand.contains("dial") -> {
                callController.handleCallCommand(lowerCommand)
            }

            // 6. Sleep Command
            lowerCommand.contains("stop listening") || lowerCommand.contains("go to sleep") -> {
                speech.speak("Going to sleep. Say Aura when you need me.")
            }

            // Fallback
            else -> {
                speech.speak("I heard: $command. Try WhatsApp, DigiLocker, call someone, or fill form.")
            }
        }
    }
}