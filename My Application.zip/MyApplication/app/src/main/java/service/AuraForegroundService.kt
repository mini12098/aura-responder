package com.aura.copilot.service

import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.widget.Toast
import com.aura.copilot.speech.IntentRouter
import com.aura.copilot.speech.SpeechManager
import com.aura.copilot.speech.WakeWordManager

class AuraForegroundService : Service() {

    private var wakeWordManager: WakeWordManager? = null
    private lateinit var speechManager: SpeechManager
    private lateinit var intentRouter: IntentRouter

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceWithNotification()

        speechManager = SpeechManager(this)
        intentRouter = IntentRouter(this, speechManager)

        wakeWordManager = WakeWordManager(this) {
            Log.i("Aura", "Wake word detected! Listening for user command...")
            showToastAndVibrate("Aura activated")

            wakeWordManager?.stop()

            Handler(Looper.getMainLooper()).postDelayed({
                speechManager.listenForCommand { command ->
                    Log.i("Aura", "Captured command: $command")
                    intentRouter.route(command)

                    wakeWordManager?.start()
                }
            }, 300)
        }

        wakeWordManager?.start()
    }

    private fun showToastAndVibrate(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    private fun startForegroundServiceWithNotification() {
        // Keeps the foreground service running persistently
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeWordManager?.stop()
        speechManager.shutdown()
    }
}