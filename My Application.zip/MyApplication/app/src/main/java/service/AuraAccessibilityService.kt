package com.aura.copilot.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aura.copilot.form.FormAutoFiller
import com.aura.copilot.speech.SpeechManager
import com.aura.copilot.util.HapticHelper

class AuraAccessibilityService : AccessibilityService() {

    private lateinit var formFiller: FormAutoFiller
    private var speechManager: SpeechManager? = null

    // Shared instance so ForegroundService / IntentRouter can reach us
    companion object {
        @Volatile var instance: AuraAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
        formFiller = FormAutoFiller(this)
        speechManager = SpeechManager(this)   // lightweight TTS only
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return

        // Payment / PIN guard – always human-in-the-loop
        if (isSensitiveScreen(root)) {
            speechManager?.speak(
                "Payment or PIN screen detected. Aura will not auto-fill. Please enter manually.",
                flush = true
            )
            HapticHelper.warning(this)
            return
        }
    }

    override fun onInterrupt() {}

    fun fillCurrentForm() {
        val root = rootInActiveWindow ?: run {
            speechManager?.speak("No active screen found.")
            return
        }
        formFiller.autoFill(root)
    }

    private fun isSensitiveScreen(root: AccessibilityNodeInfo): Boolean {
        val keywords = listOf("pin", "password", "cvv", "otp", "upi", "pay now", "confirm payment")
        return containsAnyText(root, keywords)
    }

    private fun containsAnyText(node: AccessibilityNodeInfo?, keywords: List<String>): Boolean {
        if (node == null) return false
        val text = (node.text?.toString() ?: "") + (node.contentDescription?.toString() ?: "")
        if (keywords.any { text.contains(it, ignoreCase = true) }) return true
        for (i in 0 until node.childCount) {
            if (containsAnyText(node.getChild(i), keywords)) return true
        }
        return false
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}