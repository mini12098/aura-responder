package com.aura.copilot.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

class WakeWordManager(
    private val context: Context,
    private val onWakeWordDetected: () -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var recognitionIntent: Intent
    private val handler = Handler(Looper.getMainLooper())
    private var isListening = false

    fun start() {
        handler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    Log.e("Aura", "Speech recognition not available on this device")
                    return@post
                }

                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            Log.d("Aura", "Listening for wake word...")
                        }

                        override fun onBeginningOfSpeech() {
                            Log.d("Aura", "Speech detected!")
                        }

                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}

                        override fun onError(error: Int) {
                            if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                                error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                                Log.w("Aura", "Recognizer error: $error")
                            }
                            isListening = false
                            restartListeningWithDelay()
                        }

                        override fun onResults(results: Bundle?) {
                            isListening = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            processMatches(matches)
                            restartListeningWithDelay()
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            processMatches(matches)
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }

                recognitionIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) // Force fast local processing
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    // Extend speech listening window before timing out
                    putExtra("android.speech.extra.DICTATION_MODE", true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                }

                startListeningInternal()
            } catch (e: Exception) {
                Log.e("Aura", "Exception starting SpeechRecognizer", e)
            }
        }
    }

    private fun processMatches(matches: ArrayList<String>?) {
        if (matches.isNullOrEmpty()) return
        for (result in matches) {
            val query = result.lowercase(Locale.getDefault())
            Log.i("Aura", "Heard text: \"$query\"")
            if (query.contains("aura") ||
                query.contains("ora") ||
                query.contains("or a") ||
                query.contains("porcupine")) {

                Log.i("Aura", ">>> WAKE WORD MATCHED: $result <<<")
                onWakeWordDetected()
                break
            }

            if (query.contains("aura") || query.contains("porcupine") || query.contains("ora")) {
                Log.i("Aura", ">>> WAKE WORD MATCHED: $result <<<")
                onWakeWordDetected()
                break
            }
        }
    }

    private fun startListeningInternal() {
        if (isListening) return
        handler.post {
            try {
                isListening = true
                speechRecognizer?.startListening(recognitionIntent)
            } catch (e: Exception) {
                isListening = false
                restartListeningWithDelay()
            }
        }
    }

    private fun restartListeningWithDelay() {
        handler.postDelayed({
            startListeningInternal()
        }, 500)
    }

    fun stop() {
        handler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.destroy()
                speechRecognizer = null
                isListening = false
            } catch (e: Exception) {
                Log.e("Aura", "Error stopping recognizer", e)
            }
        }
    }
}